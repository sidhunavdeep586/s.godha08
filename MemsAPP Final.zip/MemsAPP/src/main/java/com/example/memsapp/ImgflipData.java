package com.example.memsapp;

import java.util.List;

/**
 * Represents the data structure received within the response from the Imgflip API.
 */
public class ImgflipData {
    public List<Meme> memes;

    /**
     * Getter method for the list of memes.
     * @return The list of memes.
     */
    public List<Meme> getMemes() {
        return memes;
    }
}
