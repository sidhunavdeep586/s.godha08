package com.example.memsapp;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for fetching memes from the Imgflip API.
 */
public class ImgflipApiClientUtils {
    private static final ImgflipApiClient imgflipApiClient = new ImgflipApiClient();

    /**
     * Fetches memes from the Imgflip API.
     * @return A list of memes fetched from the API.
     */
    public static List<Meme> fetchMemes() {
        List<Meme> memes = new ArrayList<>();
        String responseData = imgflipApiClient.fetchDataFromApi();

        if (responseData != null && !responseData.isEmpty()) {
            Gson gson = new Gson();
            ImgflipApiResponse response = gson.fromJson(responseData, ImgflipApiResponse.class);

            if (response != null && response.isSuccess() && response.getData() != null) {
                memes.addAll(response.getData().getMemes());
            }
        }

        return memes;
    }
}
