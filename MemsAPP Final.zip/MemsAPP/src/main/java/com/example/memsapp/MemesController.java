package com.example.memsapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.util.List;

/**
 * Controller class for the Memes View.
 */
public class MemesController {
    @FXML
    private Label memesLabel;

    /**
     * Initializes the memes view with the fetched memes.
     * @param memes The list of memes to display.
     */
    public void initialize(List<Meme> memes) {
        StringBuilder memesText = new StringBuilder();
        for (Meme meme : memes) {
            memesText.append(meme.getNameUrl()).append("\n");
        }
        memesLabel.setText(memesText.toString());
    }
}
