package com.example.memsapp;

import com.google.gson.annotations.SerializedName;

/**
 * Represents a meme object.
 */
public class Meme {
    @SerializedName("id")
    public String id;

    @SerializedName("name")
    public String name;

    @SerializedName("url")
    public String url;

    /**
     * Getter method for the ID of the meme.
     * @return The ID of the meme.
     */
    public String getId() {
        return id;
    }

    /**
     * Getter method for the name of the meme.
     * @return The name of the meme.
     */
    public String getName() {
        return name;
    }

    /**
     * Getter method for the URL of the meme.
     * @return The URL of the meme.
     */
    public String getUrl() {
        return url;
    }

    /**
     * Getter method to return a concatenated string containing the name and URL of the meme.
     * @return Concatenated string of name and URL.
     */
    public String getNameUrl(){
        return "Name: " + getName() + " URL: " + getUrl();
    }
}
