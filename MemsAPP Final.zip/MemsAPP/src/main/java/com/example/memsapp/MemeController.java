package com.example.memsapp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * Controller class for the Meme Application.
 */
public class MemeController {
    @FXML
    private Label welcomeText;

    /**
     * Event handler for the button click.
     * Fetches memes from the Imgflip API and navigates to the memes view.
     */
    @FXML
    protected void onHelloButtonClick() {
        List<Meme> memes = ImgflipApiClientUtils.fetchMemes();
        openMemesView(memes);
        welcomeText.setText("Welcome to Meme Application! Please see memes view for memes.");
    }

    /**
     * Opens the memes view with the provided list of memes.
     * @param memes The list of memes to display.
     */
    private void openMemesView(List<Meme> memes) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MemeApplication.class.getResource("memes-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            MemesController memesController = fxmlLoader.getController();
            memesController.initialize(memes);

            Stage stage = new Stage();

            stage.setTitle("Memes View");
            stage.getIcons().add(new Image(Objects.requireNonNull(getClass().getResourceAsStream("icon.png"))));
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
