package com.example.memsapp;

/**
 * Represents the response received from the Imgflip API.
 */
public class ImgflipApiResponse {
    public boolean success;
    public ImgflipData data;

    /**
     * Getter method for the success status of the response.
     * @return True if the response was successful, false otherwise.
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Getter method for the data received in the response.
     * @return The data received in the response.
     */
    public ImgflipData getData() {
        return data;
    }
}
